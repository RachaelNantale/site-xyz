# Ziramba Stores

Web appliation for construction and home improvement company

## Usage

- Clone the repo

- Install all dependencies `npm install`

- To run dev mode `npm start`

- To run production build

  - Create a build `npm run build`

  - Run production server `npm start:prod`

- To get new changes `git pull`

## Contributing

Please create a separate branch and submit a pull request.

Please make sure to update tests as appropriate.
