import { combineReducers } from 'redux';
import registerReducer from './registerReducer';
import loginReducer from './loginReducer';

const Combinedreducers = combineReducers({
  registerReducer,
  loginReducer,
});

export default Combinedreducers;