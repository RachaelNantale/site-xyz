import swal from "sweetalert2";

export const passwordInvoke = async email => {
  swal.showLoading();
  const data = { email: email };
  const response = await fetch(
    "https://ziramba-backend.herokuapp.com/users/forgot-password/",
    {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-type": "application/json"
      }
    }
  );
  if (response.status === 200) {
    swal.fire({
      title: "Email sent",
      icon: "success",
      toast: true,
      position: "top",
      text: response.message
    });
    setTimeout(() => window.location.replace("/login"), 3000);
  } else {
    swal.fire({
      title: "Sorry try  again",
      icon: "error",
      toast: true,
      position: "top",
      text: response.message
    });
    setTimeout(() => window.location.replace("/recovery"), 3000);
  }
};

