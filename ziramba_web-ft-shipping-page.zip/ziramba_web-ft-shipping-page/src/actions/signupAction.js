import swal from 'sweetalert2';
import ACTION_TYPE from './actionTypes';

const userSignup = data => (dispatch) => {
  swal.showLoading();
  return fetch('https://ziramba-backend.herokuapp.com/users/register/client/',
    {
      method: 'POST',
      headers: {
        Accept: 'application/json, */*',
        'Content-type': 'application/json',
      },
      body: JSON.stringify(data),
      
    })
    .then(response => response.json()
      .then(data => ((response.ok && Promise.resolve(data)) || (!response.ok && Promise.reject(data)
      ))))
    .then((data) => {
      dispatch({
        type: ACTION_TYPE.USER_REGISTRATION,
        payload: data,
      });
      swal.fire({
        title: 'Resgistration Successful',
        text: 'Please check your email for verification',
        icon: 'success',
        confirmButtonText: 'continue',
      });
      setTimeout(() => window.location.replace('/'), 3000);
    })
    .catch((error) => {
      dispatch({
        type: ACTION_TYPE.USER_REGISTER_FAIL,
        payload: error,
      });
      swal.fire({
        title: 'Sorry, couldnt register',
        icon: 'error',
        confirmButtonText: 'Try again',
        toast: true,
        position: "top-end",
        text: error.message,
      });
    });
};
export default userSignup;
