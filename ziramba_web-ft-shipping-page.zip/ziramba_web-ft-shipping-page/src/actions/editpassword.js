import swal from "sweetalert2";


export const editPassword = async (newPass, confirmPass, token) => {
    swal.showLoading();
    const data = { password: newPass, confirm_password: confirmPass, token: token };
    const response = await fetch(
      "https://ziramba-backend.herokuapp.com/users/reset-password/",
      {
        method: "PATCH",
        body: JSON.stringify(data),
        headers: {
          Accept: 'application/json, */*',
          'Content-type': 'application/json',
        },
      }
    );
    if (response.status === 200) {
      swal.fire({
        title: "Password reset successfully",
        icon: "success",
        toast: true,
        position: "top",
        text: response.message
      });
      setTimeout(() => window.location.replace("/login"), 3000);
    } else {
      swal.fire({
        title: "Sorry check the passwords",
        icon: "error",
        toast: true,
        position: "top",
        text: response.message
      });
      setTimeout(() => window.location.replace("/reset-password"), 3000);
    }
  };
  