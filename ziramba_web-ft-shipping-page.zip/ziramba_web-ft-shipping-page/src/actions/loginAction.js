import swal from 'sweetalert2';
import ACTION_TYPE from './actionTypes';

const userLogin = data => (dispatch) => {
  swal.showLoading();
  return fetch('https://ziramba-backend.herokuapp.com/users/login/',
    {
      method: 'POST',
      headers: {
        Accept: 'application/json, */*',
        'Content-type': 'application/json',
      },
      body: JSON.stringify(data),
    })
    .then(response => (response.json())
      .then(data => ((response.ok && Promise.resolve(data)) || (!response.ok && Promise.reject(data)
      ))))
    .then((data) => {
      dispatch({
        type: ACTION_TYPE.USER_LOGIN,
        payload: data,
      });
      localStorage.setItem('token', data.access);
      swal.fire({
        title: 'Login Successful',
        icon: 'success',
        confirmButtonText: 'continue',
      });
      setTimeout(() => window.location.replace('/'), 3000);
    })
    .catch((error) => {
      dispatch({
        type: ACTION_TYPE.USER_LOGIN_FAIL,
        payload: error,
      });
      swal.fire({
        title: 'Sorry, couldnt login',
        icon: 'error',
        confirmButtonText: 'Try again',
        toast: true,
        position: "top-end",
        text: error.message,
      });
      setTimeout(() => window.location.replace('/login'), 2000);
    });
};
export default userLogin;