import React, { Component } from "react";
import "./singleProduct.scss";

class SingleProduct extends Component {
  state = {
    id: 0,
    data: [
      {
        id: 2,
        image: "http://source.unsplash.com/Geh-r9A4RBg"
      },
      {
        id: 3,
        image: "http://source.unsplash.com/CuDoRFyTkAQ"
      },
      {
        id: 4,
        image: "http://source.unsplash.com/4sZmaAzPq8M"
      }
    ]
  };

  MainImage = image => {
    return (
      <div className="col-md-9">
        <div className="order-lg-2 order-1">
          <div
            className="card bg-light border-light"
            style={{ padding: "10px", backgroundColor: "rgba(0,0,0,0.1)" }}
          >
            <img className="card-img-top" src={image} alt="Card cap" />
          </div>
        </div>
      </div>
    );
  };

  displayImages = data => {
    const results = data.map((product, index) => {
      return (
        <li onClick={() => this.setState({ id: index })}>
          <img src={product.image} alt="" />
        </li>
      );
    });
    return results;
  };
  render() {
    const id = this.state.id;

    return (
      <div className="super_container container">
        <nav>
          <ol className="breadcrumb">
            <li className="breadcrumb-item">
              <a href="/">Home</a>
            </li>
            <li className="breadcrumb-item">
              <a href="/categories">Products</a>
            </li>
            <li className="breadcrumb-item active">Cordless Drill</li>
          </ol>
        </nav>
        <div className="single_product">
          <div className="container">
            <div className="row main-man ">
              <div className="col-md-9">
                <div className="row">
                  <div className="col-md-9">
                    <div className="row">
                      <div className="col-md-3">
                        <div className=" order-lg-1 order-2">
                          <ul className="image_list">
                            {this.displayImages(this.state.data)}
                          </ul>
                        </div>
                      </div>
                      {this.MainImage(this.state.data[id].image)}
                    </div>
                  </div>
                  {/* ----------------------------------------------------- */}
                  <div className="col-md-3 order-3">
                    <div className="product_description">
                      <div className="product_name">Cordless Hand Drill</div>

                      <div>
                        {" "}
                        <span className="product_price"> UGX 29,000</span>{" "}
                        <strike className="product_discount">
                          {" "}
                          <span>UGX 2,000</span>{" "}
                        </strike>{" "}
                      </div>
                      <div>
                        {" "}
                        <span className="product_saved">You Saved:</span>{" "}
                        <span>UGX 2,000</span>{" "}
                      </div>
                      <hr className="singleline" />
                      <div className="order_info d-flex flex-row">
                        <form action="#" />
                      </div>
                      <div className="row">
                        <div className="col-xs-6">
                          <div className="product_quantity">
                            {" "}
                            <span>QTY: &nbsp; </span>
                            <input
                              id="quantity_input"
                              type="text"
                              pattern="[0-9]*"
                              value="1"
                            />
                            <div className="quantity_buttons">
                              <div
                                id="quantity_inc_button"
                                className="quantity_inc quantity_control"
                              >
                                <i className="fa fa-chevron-circle-up"></i>
                              </div>
                              <div
                                id="quantity_dec_button"
                                className="quantity_dec quantity_control"
                              >
                                <i className="fa fa-chevron-circle-down"></i>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-xs-6">
                          {" "}
                          <a
                            href="/cart"
                            role="button"
                            className="btn btn-sm btn-primary shop-button"
                          >
                            Add to Cart
                          </a>{" "}
                          <button
                            type="button"
                            className="btn btn-sm btn-success shop-button"
                          >
                            Buy Now
                          </button>
                          <button
                            type="button"
                            className="btn btn-md btn-default"
                          >
                            <i className="fa fa-heart-o"></i>
                          </button>
                        </div>
                      </div>
                      <div className="product-rating">
                        Rating: &nbsp;
                        <span className="ml-auto">
                          <i className="fa fa-star p-rating"></i>
                          <i className="fa fa-star p-rating"></i>
                          <i className="fa fa-star p-rating"></i>
                          <i className="fa fa-star p-rating"></i>
                        </span>{" "}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="col ">
                  <div className="card border-secondary mb-3">
                    {/* <div className="card-header">Header</div> */}
                    <div className="card-body text-secondary">
                      <i className="fa fa-truck"></i>
                      <h5 className="card-title">Delivery Information</h5>
                      <hr id="long-line"></hr>
                      <p className="card-text">
                        Delivered between <strong>Tuesday 10 Dec</strong> and <strong>Thursday 12 Dec</strong>&nbsp;.See
                        more
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* -----------------------------------------------xxxxxxxxxxxxxxxxx--------------------------------------------- */}
            <div className="row row-underline">
              <div className="col-md-6">
                {" "}
                <span className=" deal-text">Specifications</span>{" "}
              </div>
              <div className="col-md-6">
                {" "}
                <a href="/" data-abc="true">
                  {" "}
                  <span className="ml-auto view-all"></span>{" "}
                </a>{" "}
              </div>
            </div>
            <div className="row">
              <div className="col-md-12">
                <table className="col-md-12">
                  <tbody>
                    <tr className="row mt-10">
                      <td className="col-md-4">
                        <span className="p_specification">Sales Package :</span>{" "}
                      </td>
                      <td className="col-md-8">
                        <ul>
                          <li>
                            2 in 1 Laptop, Power Adaptor, Active Stylus Pen,
                            User Guide, Warranty Documents
                          </li>
                        </ul>
                      </td>
                    </tr>
                    <tr className="row mt-10">
                      <td className="col-md-4">
                        <span className="p_specification">Model Number :</span>{" "}
                      </td>
                      <td className="col-md-8">
                        <ul>
                          <li> 14-dh0107TU </li>
                        </ul>
                      </td>
                    </tr>
                    <tr className="row mt-10">
                      <td className="col-md-4">
                        <span className="p_specification">Part Number :</span>{" "}
                      </td>
                      <td className="col-md-8">
                        <ul>
                          <li>7AL87PA</li>
                        </ul>
                      </td>
                    </tr>
                    <tr className="row mt-10">
                      <td className="col-md-4">
                        <span className="p_specification">Color :</span>{" "}
                      </td>
                      <td className="col-md-8">
                        <ul>
                          <li>Black</li>
                        </ul>
                      </td>
                    </tr>
                    <tr className="row mt-10">
                      <td className="col-md-4">
                        <span className="p_specification">Suitable for :</span>{" "}
                      </td>
                      <td className="col-md-8">
                        <ul>
                          <li>Processing & Multitasking</li>
                        </ul>
                      </td>
                    </tr>
                    <tr className="row mt-10">
                      <td className="col-md-4">
                        <span className="p_specification">
                          Processor Brand :
                        </span>{" "}
                      </td>
                      <td className="col-md-8">
                        <ul>
                          <li>Intel</li>
                        </ul>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* -------------------------------------------------------------------------------------------------- */}
            <div className="row row-underline">
              <div className="col-md-6">
                {" "}
                <span className=" deal-text">Similar Products</span>{" "}
              </div>
              <div className="col-md-6">
                {" "}
                <a href="/" data-abc="true">
                  {" "}
                  <span className="ml-auto view-all"></span>{" "}
                </a>{" "}
              </div>
            </div>
            <div className="row">
              <div className="col-md-3">
                <div className="card">
                  <img
                    style={{height:'237px'}}
                    className="card-img-top"
                    src="https://ug.jumia.is/unsafe/fit-in/500x500/filters:fill(white)/product/91/41852/1.jpg?2541"
                    alt="Card cap"
                  />
                  <div className="card-body">
                    <div className="card-text">
                      <div class="row">
                        <div
                          className="col-sm-6"
                          style={{ textAlign: "left", display: "block" }}
                        >
                          <del>
                            <small disabled>UGX 32,000</small>
                          </del>
                        </div>
                        <div
                          className="col-sm-6"
                          style={{ textAlign: "right" }}
                        >
                          <i className="fa fa-star p-rating"></i>
                          <i className="fa fa-star p-rating"></i>
                          <i className="fa fa-star p-rating"></i>
                          <i className="fa fa-star p-rating"></i>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-sm-6" style={{textAlign:'left'}}>UGX 30,000</div>
                        <div className="col-sm-6 fs-10" style={{textAlign:'right'}}>23 Reviews</div>
                      </div>{" "}
                      <span>Acer laptop with 10GB RAM + 500 GB Hard Disk</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="card bg-light border-light">
                  <img
                    style={{height:'237px'}}
                    className="card-img-top"
                    src="https://ug.jumia.is/unsafe/fit-in/500x500/filters:fill(white)/product/91/41852/1.jpg?2541"
                    alt="Card cap"
                  />
                  <div className="card-body">
                    <div className="card-text">
                      <div class="row">
                        <div
                          className="col-sm-6"
                          style={{ textAlign: "left", display: "block" }}
                        >
                          <del>
                            <small>UGX 32,000</small>
                          </del>
                        </div>
                        <div
                          className="col-sm-6"
                          style={{ textAlign: "right" }}
                        >
                          <i className="fa fa-star p-rating"></i>
                          <i className="fa fa-star p-rating"></i>
                          <i className="fa fa-star p-rating"></i>
                          <i className="fa fa-star p-rating"></i>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-sm-6" style={{textAlign:'left'}}>UGX 30,000</div>
                        <div className="col-sm-6 fs-10" style={{textAlign:'right'}}>23 Reviews</div>
                      </div>{" "}
                      <span>Acer laptop with 10GB RAM + 500 GB Hard Disk</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="card bg-light border-light">
                  <img
                    style={{height:'237px'}}
                    className="card-img-top"
                    src="https://ug.jumia.is/unsafe/fit-in/500x500/filters:fill(white)/product/91/41852/1.jpg?2541"
                    alt="Card cap"
                  />
                  <div className="card-body">
                    <div className="card-text">
                      <div class="row">
                        <div
                          className="col-sm-6"
                          style={{ textAlign: "left", display: "block" }}
                        >
                          <del>
                            <small>UGX 32,000</small>
                          </del>
                        </div>
                        <div
                          className="col-sm-6"
                          style={{ textAlign: "right" }}
                        >
                          <i className="fa fa-star p-rating"></i>
                          <i className="fa fa-star p-rating"></i>
                          <i className="fa fa-star p-rating"></i>
                          <i className="fa fa-star p-rating"></i>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-sm-6" style={{textAlign:'left'}}>UGX 30,000</div>
                        <div className="col-sm-6 fs-10" style={{textAlign:'right'}}>23 Reviews</div>
                      </div>{" "}
                      <span>Acer laptop with 10GB RAM + 500 GB Hard Disk</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="card bg-light border-light">
                  <img
                    style={{height:'237px'}}
                    className="card-img-top"
                    src="https://ug.jumia.is/unsafe/fit-in/500x500/filters:fill(white)/product/91/41852/1.jpg?2541"
                    alt="Card cap"
                  />
                  <div className="card-body">
                    <div className="card-text">
                      <div class="row">
                        <div
                          className="col-sm-6"
                          style={{ textAlign: "left", display: "block" }}
                        >
                          <del>
                            <small>UGX 32,000</small>
                          </del>
                        </div>
                        <div
                          className="col-sm-6"
                          style={{ textAlign: "right" }}
                        >
                          <i className="fa fa-star p-rating"></i>
                          <i className="fa fa-star p-rating"></i>
                          <i className="fa fa-star p-rating"></i>
                          <i className="fa fa-star p-rating"></i>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-sm-6" style={{textAlign:'left'}}>UGX 30,000</div>
                        <div className="col-sm-6 fs-10" style={{textAlign:'right'}}>23 Reviews</div>
                      </div>{" "}
                      <span>Acer laptop with 10GB RAM + 500 GB Hard Disk</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default SingleProduct;
