import React from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import SignupConnected from "../../containers/Signup";
import "./index.css";
import Cart from "../Cart/Cart";
import Homepage from "../../containers/Homepage";
import Login from "../../containers/Login";
import Product from "../../containers/Product";
import ProductsList from "../../containers/ProductsList";
import ForgotPasswordPage from "../../containers/Password/ForgotPassword";
import EditPasswordPage from "../../containers/Password/EditPassword";
import Navbar from "../../containers/Navbar";
import Footer from "../../containers/Footer";
import Checkout from "../Checkout/checkout";

const App = () => (
  <BrowserRouter>
    <React.Fragment>
      <Navbar/>
      <Switch>
        <Route exact path="/" component={Homepage} />
        <Route path="/signup" component={SignupConnected} />
        <Route path="/login" component={Login} />
        <Route path="/recovery" component={ForgotPasswordPage} />
        <Route path="/categories" component={ProductsList} />
        <Route path="/products/id" component={Product} />
        <Route path="/cart" component={Cart}/>
        <Route path="/reset-password" component={EditPasswordPage} />
        
      </Switch>
      <Footer/>
    </React.Fragment>
    <Checkout/>
  </BrowserRouter>
);
export default App;
