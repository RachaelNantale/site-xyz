import React from 'react';
import './checkout.scss';

const Payments = () => (
    <div className="container">
            <ul class="stop d-flex flex-nowrap">
                <li class="step-item">
                    <a href="#!" class="">
                        Shipping
                    </a>
                </li>
                <li class="step-item">
                    <a href="#!" class="">
                        Billing
                    </a>
                </li>
                <li class="step-item active">
                    <a href="#!" class="">
                        Payments
                    </a>
                </li>
                <li class="step-item">
                    <a href="#!" class="">
                        Summary
                    </a>
                </li>
            </ul>
        <h4 className="mb-3">Payment</h4>

        <div className="d-block my-3">
            <div className="custom-control custom-radio">
                <input
                    id="credit"
                    name="paymentMethod"
                    type="radio"
                    className="custom-control-input"
                    checked
                    required
                />
                <label className="custom-control-label" for="credit">
                    Credit card
                </label>
            </div>
            <div className="custom-control custom-radio">
                <input
                    id="debit"
                    name="paymentMethod"
                    type="radio"
                    className="custom-control-input"
                    required
                />
                <label className="custom-control-label" for="debit">
                    Debit card
                </label>
            </div>
            <div className="custom-control custom-radio">
                <input
                    id="paypal"
                    name="paymentMethod"
                    type="radio"
                    className="custom-control-input"
                    required
                />
                <label className="custom-control-label" for="paypal">
                    PayPal
                </label>
            </div>
            <div className="custom-control custom-radio">
                <input
                    id="paypal"
                    name="paymentMethod"
                    type="radio"
                    className="custom-control-input"
                    required
                />
                <label className="custom-control-label" for="paypal">
                    Mobile Money
                </label>
            </div>
        </div>
        <div className="row">
            <div className="col-md-6 mb-3">
                <label for="cc-name">Name on card</label>
                <input
                    type="text"
                    className="form-control"
                    id="cc-name"
                    placeholder=""
                    required
                />
                <small className="text-muted">
                    Full name as displayed on card
                </small>
                <div className="invalid-feedback">Name on card is required</div>
            </div>
            <div className="col-md-6 mb-3">
                <label for="cc-number">Credit card number</label>
                <input
                    type="text"
                    className="form-control"
                    id="cc-number"
                    placeholder=""
                    required
                />
                <div className="invalid-feedback">
                    Credit card number is required
                </div>
            </div>
        </div>
        <div className="row">
            <div className="col-md-3 mb-3">
                <label for="cc-expiration">Expiration</label>
                <input
                    type="text"
                    className="form-control"
                    id="cc-expiration"
                    placeholder=""
                    required
                />
                <div className="invalid-feedback">Expiration date required</div>
            </div>
            <div className="col-md-3 mb-3">
                <label for="cc-cvv">CVV</label>
                <input
                    type="text"
                    className="form-control"
                    id="cc-cvv"
                    placeholder=""
                    required
                />
                <div className="invalid-feedback">Security code required</div>
            </div>
        </div>
        <div className="row">
            <div className="col-md-6 mb-3">
                <label for="cc-name">Name registered on number</label>
                <input
                    type="text"
                    className="form-control"
                    id="cc-name"
                    placeholder=""
                    required
                />
                <small className="text-muted">
                    Full name as registered by number
                </small>
                <div className="invalid-feedback">
                    Name registered on number
                </div>
            </div>
            <div className="col-md-6 mb-3">
                <label for="cc-number">Phone number</label>
                <input
                    type="text"
                    className="form-control"
                    id="cc-number"
                    placeholder=""
                    required
                />
                <div className="invalid-feedback">Phone number</div>
            </div>
        </div>
    </div>
);
export default Payments;
