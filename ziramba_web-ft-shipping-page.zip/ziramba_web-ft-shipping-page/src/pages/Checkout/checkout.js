import React from 'react';
import './checkout.scss';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import Shipping from '../Checkout/shipping';
import Billing from '../Checkout/billing';
import Payments from '../Checkout/payments';

const Checkout = () => (
    <BrowserRouter>
        <Switch>
            <Route path="/checkout/billing" component={Billing} />
            <Route path="/checkout/shipping" component={Shipping} />
            <Route path="/checkout/payments" component={Payments} />
        </Switch>
    </BrowserRouter>
);

export default Checkout;
