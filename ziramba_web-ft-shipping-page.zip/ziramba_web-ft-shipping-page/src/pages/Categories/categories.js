import React from "react";
import "./categories.scss";
// import PropTypes from 'prop-types';
// import { Link } from 'react-router-dom';

const CategoryDisplay = () => (
  <div className="container">
    <h3 className="text-center font-weight-bold">Shop Popular Products</h3>
    <div className="row">
      <div
        className="col-lg-3 col-md-4 col-sm-6 col-xs-6
      "
      >
        <div className="hovereffect">
          <img
            className="img-responseive d-block w-100"
            src="http://source.unsplash.com/wMYyR4c2XjI"
            alt="aluminium "
          />
          <div className="overlay">
            <h2>Aluminium</h2>
            <a className="info" href="/categories">
              link here
            </a>
          </div>
        </div>
      </div>
      <div
        className="col-lg-3 col-md-4 col-sm-6 col-xs-6
      "
      >
        <div className="hovereffect">
          <img
            className="img-responseive d-block w-100"
            src="http://source.unsplash.com/YfRIrfieGac"
            alt="Brick"
          />
          <div className="overlay">
            <h2>Brick</h2>
            <a className="info" href="/categories">
              link here
            </a>
          </div>
        </div>
      </div>

      <div
        className="col-lg-3 col-md-4 col-sm-6 col-xs-6
      "
      >
        <div className="hovereffect">
          <img
            className="img-responseive d-block w-100"
            src="http://source.unsplash.com/eu9VsGh12Gc"
            alt="Glass"
          />
          <div className="overlay">
            <h2>Glass</h2>
            <a className="info" href="/categories">
              link here
            </a>
          </div>
        </div>
      </div>
      <div
        className="col-lg-3 col-md-4 col-sm-6 col-xs-6
      "
      >
        <div className="hovereffect">
          <img
            className="img-responseive d-block w-100"
            src="http://source.unsplash.com/eu9VsGh12Gc"
            alt="Glass"
          />
          <div className="overlay">
            <h2>Plastic</h2>
            <a className="info" href="/categories">
              link here
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default CategoryDisplay;
