import React from 'react';
import './cart.scss';

const Cart = () => (
    <div className="container pt-5">
        <div className="row">
            <div className="col-sm-8">
                <div className="">
                    <div className="d-flex bd-highlight mb-3">
                        <h4 className="mr-auto  p-2 bd-highlight">
                            <strong>ITEM</strong>
                        </h4>
                        <h4 className="p-2 bd-highlight">
                            <strong>PRICE</strong>
                        </h4>
                    </div>
                    <hr></hr>
                    <div className="row cart-items">
                        <div className="col-sm-4">
                            <img
                                class="cart-img"
                                src="http://source.unsplash.com/MXeDE_yCdHQ"
                                alt="..."
                            />
                        </div>
                        <div className="col-sm-6">
                            <h4>
                                Automatic rechargeable battery powered drill
                                machine
                            </h4>
                            <form className="form-inline">
                                <div className="form-group">
                                    <label for="Quantity">
                                        Quantity &nbsp;
                                    </label>
                                    <select
                                        class="form-control"
                                        id="exampleFormControlSelect1"
                                    >
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                    </select>
                                </div>
                            </form>
                            <div className="d-flex bd-highlight mb-3">
                                <a
                                    className="mr-5  p-2 bd-highlight"
                                    href="/delete"
                                >
                                    Delete
                                </a>
                                <a
                                    className="p-2 bd-highlight"
                                    href="/products/id"
                                >
                                    Details
                                </a>
                            </div>
                            <form class="form-inline">
                                <div class="form-group">
                                    <label for="Coupon">
                                        Apply Coupon &nbsp;{' '}
                                    </label>
                                    <input type="text" class="form-control" />
                                </div>
                            </form>
                        </div>
                        <div className="col-sm-2">
                            <strong>Shs 490000</strong>
                        </div>
                    </div>
                    <hr />
                </div>
                <div className="">
                    <div className="row">
                        <div className="col-sm-4 pa-5">
                            <img
                                class="cart-img"
                                src="http://source.unsplash.com/MXeDE_yCdHQ"
                                alt="..."
                            />
                        </div>
                        <div className="col-sm-6 pa-5">
                            <h4>
                                Automatic rechargeable battery powered drill
                                machine
                            </h4>
                            <form className="form-inline">
                                <div className="form-group">
                                    <label for="Quantity">
                                        Quantity &nbsp;
                                    </label>
                                    <select
                                        class="form-control"
                                        id="exampleFormControlSelect1"
                                    >
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                    </select>
                                </div>
                            </form>
                            <div className="d-flex bd-highlight mb-3">
                                <a
                                    className="mr-5 p-2 bd-highlight"
                                    href="/delete"
                                >
                                    Delete
                                </a>
                                <a
                                    className="p-2 bd-highlight"
                                    href="/products/id"
                                >
                                    Details
                                </a>
                            </div>
                            <form class="form-inline">
                                <div class="form-group">
                                    <label for="Coupon">
                                        Apply Coupon &nbsp;
                                    </label>
                                    <input type="text" class="form-control" />
                                </div>
                            </form>
                        </div>
                        <div className="col-sm-2 pa-5">
                            <strong>Shs 490000</strong>
                        </div>
                    </div>
                    <hr />
                </div>
            </div>
            {/* ================================================================================================== */}

            <div className="col-sm-4">
                <div className="card price-div">
                    <h4>Subtotal:</h4> <strong>4900000</strong>
                    <a
                        href="/checkout/shipping"
                        role="button"
                        class="btn btn-primary btn-lg"
                    >
                        Proceed to checkout
                    </a>
                </div>
                <br></br>
                <br></br>
                <h4 className="cart-recent-items">Recently Viewed Items</h4>
                <div className="card cart-recent-viewed ">
                    <div className="row row-cart-recent-viewed">
                        <div className="col-sm-6">
                            <img
                                className="cart-recent-img"
                                src="https://is4.revolveassets.com/images/p4/n/c/PRIP-WK36_V1.jpg"
                                alt="Card cap"
                            />
                        </div>
                        <div className="col-sm-6 recent-items-details">
                            <a href="/products/id">Cordless drill</a>
                            <div className="">
                                <i className="fa fa-star p-rating"></i>
                                <i className="fa fa-star p-rating"></i>
                                <i className="fa fa-star p-rating"></i>
                                <i className="fa fa-star p-rating"></i>
                            </div>
                            <p className="price-cart-recent-items">Shs 3000</p>
                            <a
                                href="/cart"
                                role="button"
                                className="btn btn-sm cart-button"
                            >
                                + Add to Cart
                            </a>{' '}
                        </div>
                    </div>
                    <div className="row row-cart-recent-viewed">
                        <div className="col-sm-6">
                            <img
                                className="cart-recent-img"
                                src="https://ug.jumia.is/unsafe/fit-in/500x500/filters:fill(white)/product/91/41852/1.jpg?2541"
                                alt="Card cap"
                            />
                        </div>
                        <div className="col-sm-6 recent-items-details">
                            <a href="/products/id">Cordless drill</a>
                            <div className="">
                                <i className="fa fa-star p-rating"></i>
                                <i className="fa fa-star p-rating"></i>
                                <i className="fa fa-star p-rating"></i>
                                <i className="fa fa-star p-rating"></i>
                            </div>
                            <p className="price-cart-recent-items">Shs 3000</p>
                            <a
                                href="/cart"
                                role="button"
                                className="btn btn-sm cart-button"
                            >
                                + Add to Cart
                            </a>{' '}
                        </div>
                    </div>{' '}
                    <div className="row ">
                        <div className="col-sm-6">
                            <img
                                className="cart-recent-img"
                                src="https://ug.jumia.is/p0voOiqGGW1ZLJOJap8Z8oURGWY=/fit-in/60x60/filters:fill(white):sharpen(1,0,false):quality(100)/product/01/03371/1.jpg?7804"
                                alt="Card cap"
                            />
                        </div>
                        <div className="col-sm-6 recent-items-details">
                            <a href="/products/id">Cordless drill</a>
                            <div className="">
                                <i className="fa fa-star p-rating"></i>
                                <i className="fa fa-star p-rating"></i>
                                <i className="fa fa-star p-rating"></i>
                                <i className="fa fa-star p-rating"></i>
                            </div>
                            <p className="price-cart-recent-items">Shs 3000</p>
                            <a
                                href="/cart"
                                role="button"
                                className="btn btn-sm cart-button"
                            >
                                + Add to Cart
                            </a>{' '}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br></br>
        <br></br>
        {/* ++++++++++++++++++++++++++++++++++++++++++++++ */}
        <h4>Products normally bought with items in your cart</h4>
        <br></br>
        <br></br>
        <div className="row">
            <div className="col-md-3">
                <div className="card cart-products">
                    <a href="/products/id">
                        <img
                            className="cart-recent-img"
                            src="https://ug.jumia.is/unsafe/fit-in/500x500/filters:fill(white)/product/91/41852/1.jpg?2541"
                            alt="Card cap"
                        />
                    </a>
                    <div className="card-body">
                        <div className="card-text">
                            <div class="row">
                                <div
                                    className="col-sm-6"
                                    style={{
                                        textAlign: 'left',
                                        display: 'block',
                                    }}
                                >
                                    <del>
                                        <small disabled>UGX 32,000</small>
                                    </del>
                                </div>
                                <div
                                    className="col-sm-6"
                                    style={{ textAlign: 'right' }}
                                >
                                    <i className="fa fa-star p-rating"></i>
                                    <i className="fa fa-star p-rating"></i>
                                    <i className="fa fa-star p-rating"></i>
                                    <i className="fa fa-star p-rating"></i>
                                </div>
                            </div>
                            <div className="row">
                                <div
                                    className="col-sm-6"
                                    style={{ textAlign: 'left' }}
                                >
                                    UGX 30,000
                                </div>
                                <div
                                    className="col-sm-6 fs-10"
                                    style={{ textAlign: 'right' }}
                                >
                                    23 Reviews
                                </div>
                            </div>{' '}
                            <span>
                                Acer laptop with 10GB RAM + 500 GB Hard Disk
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div className="col-md-3">
                <div className="card cart-products">
                    <img
                        className="cart-recent-img"
                        src="https://ug.jumia.is/tlGzx9MgtSCYtgx2TRckZ4GURns=/fit-in/220x220/filters:fill(white):sharpen(1,0,false):quality(100)/product/73/55672/1.jpg?7428"
                        alt="Card cap"
                    />
                    <div className="card-body">
                        <div className="card-text">
                            <div class="row">
                                <div
                                    className="col-sm-6"
                                    style={{
                                        textAlign: 'left',
                                        display: 'block',
                                    }}
                                >
                                    <del>
                                        <small disabled>UGX 32,000</small>
                                    </del>
                                </div>
                                <div
                                    className="col-sm-6"
                                    style={{ textAlign: 'right' }}
                                >
                                    <i className="fa fa-star p-rating"></i>
                                    <i className="fa fa-star p-rating"></i>
                                    <i className="fa fa-star p-rating"></i>
                                    <i className="fa fa-star p-rating"></i>
                                </div>
                            </div>
                            <div className="row">
                                <div
                                    className="col-sm-6"
                                    style={{ textAlign: 'left' }}
                                >
                                    UGX 30,000
                                </div>
                                <div
                                    className="col-sm-6 fs-10"
                                    style={{ textAlign: 'right' }}
                                >
                                    23 Reviews
                                </div>
                            </div>{' '}
                            <span>
                                Acer laptop with 10GB RAM + 500 GB Hard Disk
                            </span>
                        </div>
                    </div>
                </div>
            </div>{' '}
            <div className="col-md-3">
                <div className="card cart-products">
                    <img
                        className="card-img-top cart-recent-img"
                        src="https://ug.jumia.is/unsafe/fit-in/500x500/filters:fill(white)/product/91/41852/1.jpg?2541"
                        alt="Card cap"
                    />
                    <div className="card-body">
                        <div className="card-text">
                            <div class="row">
                                <div
                                    className="col-sm-6"
                                    style={{
                                        textAlign: 'left',
                                        display: 'block',
                                    }}
                                >
                                    <del>
                                        <small disabled>UGX 32,000</small>
                                    </del>
                                </div>
                                <div
                                    className="col-sm-6"
                                    style={{ textAlign: 'right' }}
                                >
                                    <i className="fa fa-star p-rating"></i>
                                    <i className="fa fa-star p-rating"></i>
                                    <i className="fa fa-star p-rating"></i>
                                    <i className="fa fa-star p-rating"></i>
                                </div>
                            </div>
                            <div className="row">
                                <div
                                    className="col-sm-6"
                                    style={{ textAlign: 'left' }}
                                >
                                    UGX 30,000
                                </div>
                                <div
                                    className="col-sm-6 fs-10"
                                    style={{ textAlign: 'right' }}
                                >
                                    23 Reviews
                                </div>
                            </div>{' '}
                            <span>
                                Acer laptop with 10GB RAM + 500 GB Hard Disk
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
);
export default Cart;
