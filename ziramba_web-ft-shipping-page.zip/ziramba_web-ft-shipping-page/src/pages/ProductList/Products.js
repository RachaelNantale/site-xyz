import React, {Component} from "react";
import "./products.scss";


const data = [
  {
    name: "Automatic rechargeable battery powered drill machine",
    image: "http://source.unsplash.com/MXeDE_yCdHQ",
    price: "$16.00",
    crossed_price: "$20.00"
  },
  {
    name: "Automatic rechargeable battery powered drill machine",
    image: "http://source.unsplash.com/MXeDE_yCdHQ",
    price: "$16.00",
    crossed_price: "$20.00"
  },
  {
    name: "Automatic rechargeable battery powered drill machine",
    image: "http://source.unsplash.com/MXeDE_yCdHQ",
    price: "$16.00",
    crossed_price: "$20.00"
  },
  {
    name: "Automatic rechargeable battery powered drill machine",
    image: "http://source.unsplash.com/MXeDE_yCdHQ",
    price: "$16.00",
    crossed_price: "$20.00"
  },
  {
    name: "Automatic rechargeable battery powered drill machine",
    image: "http://source.unsplash.com/MXeDE_yCdHQ",
    price: "$16.00",
    crossed_price: "$20.00"
  },
  {
    name: "Automatic rechargeable battery powered drill machine",
    image: "http://source.unsplash.com/MXeDE_yCdHQ",
    price: "$16.00",
    crossed_price: "$20.00"
  },
  {
    name: "Automatic rechargeable battery powered drill machine",
    image: "http://source.unsplash.com/MXeDE_yCdHQ",
    price: "$16.00",
    crossed_price: "$20.00"
  }
];



class Products extends Component{
  displayProducts(data) {
    const result = data.map(product => {
      return (<div class="col-md-3 col-sm-6 products-column">
      <div class="product-grid">
        <div class="product-image">
          <a href="/products/id">
            <img
              class="pic-1"
              src="http://source.unsplash.com/MXeDE_yCdHQ"
              alt="..."
            />
          </a>
          <span class="product-new-label">Sale</span>
          <span class="product-discount-label">20%</span>
        </div>
        <ul class="rating">
          <li class="fa fa-star"></li>
          <li class="fa fa-star"></li>
          <li class="fa fa-star"></li>
          <li class="fa fa-star"></li>
          <li class="fa fa-star disable"></li>
        </ul>
        <div class="product-content">
          <h3 class="title">
            <a href="/products/id">Automatic rechargeable battery powered drill machine</a>
          </h3>
          <div class="price">
            $16.00
            <span>$20.00</span>
          </div>
          <a class="add-to-cart" href="/">
            + Add To Cart
          </a>
        </div>
      </div>
    </div>)
    });
    return result;
  }
  render(){
    return(<div class="container">
    <h3 class="h3">Products </h3>
    <div class="row">
      {this.displayProducts(data)}
  </div>
  </div>)
  }
}

export default Products;
