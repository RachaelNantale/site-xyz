import React from 'react';
import PropTypes from 'prop-types';
import { Link } from "react-router-dom";
import {
  Button,
  Form,
  Grid,
  Header,
  Message,
  Segment,
  Image
} from "semantic-ui-react";

import logo from "../../assets/main_logo_edited.png";

const Register = ({onChange, onSubmit}) => (
    <Grid
        textAlign="center"
        style={{ height: "100vh" }}
        verticalAlign="middle"
        className="container"
      >
        <Grid.Column style={{ maxWidth: 600 }}>
          <Image as="a" href="/" src={logo} size="small" />
          <Header as="h2" color="teal" textAlign="center">
            Sign up for free!
          </Header>
          <Form size="large" onSubmit={onSubmit}>
            <Segment stacked>
              <Form.Input
                fluid
                icon="user"
                iconPosition="left"
                placeholder="First name"
                name="firstName"
                onChange={onChange}
              />
              <Form.Input
                fluid
                icon="user"
                iconPosition="left"
                placeholder="Last name"
                name="lastName"
                onChange={onChange}
              />
              <Form.Input
                fluid
                icon="envelope"
                iconPosition="left"
                placeholder="E-mail address"
                name="email"
                onChange={onChange}
              />
              <Form.Input
                fluid
                icon="lock"
                iconPosition="left"
                placeholder="Password"
                name="password"
                type="password"
                onChange={onChange}
              />
              <Form.Input
                fluid
                icon="phone"
                iconPosition="left"
                placeholder="+256708888777"
                name="phoneNumber"
                onChange={onChange}
              />

              <Button color="teal" fluid size="large" type="submit"  onClick={onSubmit}>
                Create account
              </Button>
            </Segment>
          </Form>
          <Message>
            <Link to="/login"> Return to login </Link>
          </Message>
        </Grid.Column>
      </Grid>
);
Register.propTypes = {
    onChange: PropTypes.func.isRequired,
    onSubmit: PropTypes.func.isRequired,
  };

export default Register;