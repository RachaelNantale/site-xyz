import React from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import {
  Button,
  Form,
  Grid,
  Header,
  Message,
  Segment,
  Divider,
  Image
} from "semantic-ui-react";
import logo from  "../../assets/main_logo_edited.png";

const Login = ({ onChange, onSubmit }) => (
  <Grid textAlign="center" style={{ height: "100vh" }} verticalAlign="middle" className="container">
    <Grid.Column style={{ maxWidth: 450 }}>
      <Image as="a" href="/" src={logo} size="small" />
      <Header as="h2" color="teal" textAlign="center">
        Login to your account
      </Header>
      <Form size="large" onSubmit={onSubmit}>
        <Segment stacked>
          <Form.Input
            fluid
            name="email"
            icon="user"
            iconPosition="left"
            placeholder="E-mail address"
            onChange={onChange}
          />
          <Form.Input
            fluid
            name="password"
            icon="lock"
            iconPosition="left"
            placeholder="Password"
            type="password"
            onChange={onChange}
          />

          <Button color="teal" fluid size="large" type="submit">
            Login
          </Button>
          <Divider />
          <Link to="/recovery"> Having trouble login in? </Link>
        </Segment>
      </Form>
      <Message>
        Don't have an account? <Link to="/signup"> Sign Up </Link>
      </Message>
    </Grid.Column>
  </Grid>
);

Login.propTypes = {
  onChange: PropTypes.func.isRequired,
  onSubmit: PropTypes.func.isRequired
};

export default Login;
