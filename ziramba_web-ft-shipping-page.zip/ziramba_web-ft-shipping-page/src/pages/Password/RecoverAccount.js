import React from 'react';
import {
    Link
} from 'react-router-dom';

import { Button, Divider, Grid, Header, Form, Image } from 'semantic-ui-react'

import logo from  "../../assets/main_logo_edited.png";

const RecoverAccount = ({ handleSubmit,handleChange, emailError }) =>(
    <Grid textAlign='center' style={{ height: '100vh' }} verticalAlign='middle' className="container">
    <Grid.Column style={{ maxWidth: 450 }}>
    <Image as="a" href="/" src={logo} size="small" />
      <Header as='h2' textAlign='center'>
        Need help with your password?
      </Header>
      <p>Enter the email you use for Ziramba, and we’ll help you create a new password.</p>
      <Form size='large' onSubmit={handleSubmit}>
          <Form.Input fluid icon='user' iconPosition='left' name="email" placeholder='E-mail address' onChange={handleChange} />
          <span className="text-danger">
            {emailError != null ? emailError : null}
          </span>

          <Button color='teal' fluid size='large' type='submit'>
            Send instructions
          </Button>
      </Form>
      <Divider horizontal> or </Divider>
      <Link to='/login'> Return to login </Link>
      <Divider hidden />
    </Grid.Column>
  </Grid>
)

export default RecoverAccount;