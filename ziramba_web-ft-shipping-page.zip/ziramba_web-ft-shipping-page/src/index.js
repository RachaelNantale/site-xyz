import "bootstrap/dist/css/bootstrap.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";
import store from "./store";
import App from "./pages/App/App";
import Checkout from "./pages/Checkout/checkout";

ReactDOM.render(
  <Provider store={store}>
    <App />
    {/* <Checkout/> */}
  </Provider>,
  document.getElementById("root")
);
