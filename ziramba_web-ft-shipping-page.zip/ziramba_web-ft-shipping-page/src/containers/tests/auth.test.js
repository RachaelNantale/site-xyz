import React from 'react';
import { shallow } from 'enzyme';
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import SignupConnected, { mapDispatchToProps, Signup } from '../Signup';
import LoginPageConnected, { mapDispatchToProps as mapToProps, LoginPage } from '../Login';

import ACTION_TYPE from '../../actions/actionTypes';

const mockStore = configureMockStore([thunk]);
let store;
const initialState = {
  registerReducer: {
  freshUser: {
    first_name: '',
    last_name: '',
    email: '',
    password: '',
    phone_number: '',
  },
},
};
const login_initialState = {
  loginReducer: {
  freshUser: {
    email: '',
    password: '',
  },
},
};



describe('<Signup />', () => {
   let SignupComponent;
  let LoginPageComponent;
  let wrapper;
  // beforeEach(() => {
  //   SignupComponent = shallow(<SignupConnected store={mockStore(initialState)} />);
  // });
  // beforeEach(() => {
  //   LoginPageComponent = shallow(<LoginPageConnected  store={mockStore(login_initialState)}/>);
  // });

  it('should render the signup component', () => {
    expect(SignupComponent).toMatchSnapshot();
  });
  it('should render the login component', () => {
    expect(LoginPageComponent).toMatchSnapshot();
  });

  it('should dispatch a method to  get   signup user input', () => {
    const dispatch = jest.fn();
    mapDispatchToProps(dispatch).getUserInputs({});
    expect(dispatch.mock.calls[0][0]).toEqual({ payload: {}, type: ACTION_TYPE.GET_USER_INPUT });
    mapDispatchToProps(dispatch).signUpuser({});
  });

  it('should dispatch a method to get  login user input', () => {
    const dispatch = jest.fn();
    mapDispatchToProps(dispatch).getUserInputs({});
    expect(dispatch.mock.calls[0][0]).toEqual({ payload: {}, type: ACTION_TYPE.GET_USER_INPUT });
    mapToProps(dispatch).loginUser({});
  });

  it('should call handle input user method', () => {
    const getUserInputs = jest.fn();
    wrapper = shallow(
      <Signup
        signUpuser={jest.fn()}
        freshUser={{}}
        getUserInputs={getUserInputs}
      />,
      <LoginPage
      loginUser={jest.fn()}
      freshUser={{}}
      getUserInputs={getUserInputs}
    />,
    );
    wrapper.instance().handleUpdateFields({ target: { name: 'username', value: 'rachael' } });
    expect(getUserInputs).toHaveBeenCalled();
  });
});

describe('handle signup', () => {
  const wrapper = shallow(<Signup />);
  wrapper.setProps({ signUpuser: jest.fn() });
  const fakeEventReturn = { target: { id: 1, value: 'some val' } };
  const fakeEvent = { preventDefault: () => fakeEventReturn };
  const spy = jest.spyOn(wrapper.instance(), 'handleSignUp');
  wrapper.instance().handleSignUp(fakeEvent);
  expect(spy).toHaveBeenCalled();
});

describe('handle login', () => {
  const wrapper = shallow(<LoginPage />);
  wrapper.setProps({ loginUser: jest.fn() });
  const fakeEventReturn = { target: { id: 1, value: 'some val' } };
  const fakeEvent = { preventDefault: () => fakeEventReturn };
  const spy = jest.spyOn(wrapper.instance(), 'handleLogin');
  wrapper.instance().handleLogin(fakeEvent);
  expect(spy).toHaveBeenCalled();
});