import React from "react";

import {
  Container,
  Divider,
  Grid,
  Header,
  Image,
  List,
  Segment,
  Button
} from "semantic-ui-react";

import logo from "./../assets/main_logo_edited.png";

const Footer = () => (
  <Segment
    inverted
    vertical
    color="teal"
    style={{ margin: "5em 0em 0em", padding: "5em 0em" }}
  >
    <Container textAlign="center">
      <Grid divided inverted stackable>
        <Grid.Column width={3}>
          <Header inverted as="h4" content="Explore Ziramba" />
          <List link inverted>
            <List.Item as="a">Brands</List.Item>
            <List.Item as="a">Installation Service</List.Item>
            <List.Item as="a">Ziramba Credit Card</List.Item>
            <List.Item as="a">All Departments</List.Item>
          </List>
        </Grid.Column>
        <Grid.Column width={3}>
          <Header inverted as="h4" content="Customer Service" />
          <List link inverted>
            <List.Item as="a">FAQ</List.Item>
            <List.Item as="a">Contact info</List.Item>
            <List.Item as="a">Shipping & Returns</List.Item>
          </List>
        </Grid.Column>
        <Grid.Column width={3}>
          <Header inverted as="h4" content="Resources" />
          <List link inverted>
            <List.Item as="a">Careers</List.Item>
            <List.Item as="a">Press Kit</List.Item>
            <List.Item as="a">Affiliate Program</List.Item>
            <List.Item as="a">Glossary of terms</List.Item>
          </List>
        </Grid.Column>
        <Grid.Column width={7}>
          <Header inverted as="h4" content="Your voice matters" />
          <p>
            We 'd love to learn more about your shopping experiences on
            Ziramba.com and how we can improve!.
          </p>
          <Button> Take Survey</Button>
        </Grid.Column>
      </Grid>

      <Divider inverted section />
      <Image centered size="small" src={logo} />
      <List horizontal inverted divided link size="small">
        <List.Item as="a" href="#">
          Site Map
        </List.Item>
        <List.Item as="a" href="#">
          Contact Us
        </List.Item>
        <List.Item as="a" href="#">
          Terms and Conditions
        </List.Item>
        <List.Item as="a" href="#">
          Privacy Policy
        </List.Item>
      </List>
    </Container>
  </Segment>
);

export default Footer;
