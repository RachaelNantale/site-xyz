import React, { Component } from 'react';
import { connect } from 'react-redux';
import ResetPassword from '../../pages/Password/EditPassword';
import { editPassword } from '../../actions/editpassword';

class EditPasswordPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      newPassword: '',
      confPassword: '',
    };
  }

  handleChange = (event) => {
      this.setState({ [event.target.name]: event.target.value });
  };

  handleSubmit = (event) => {
    event.preventDefault();

    const myToken = window.location.href;
    const token = myToken.toString().substring(myToken.lastIndexOf('?') + 1);
    console.log(token, '========TOken+++++++++++')
    const { newPassword, confPassword } = this.state;
    
    editPassword(newPassword, confPassword, token);
    console.log(this.state);

  };

  render() {
    return (
      <ResetPassword
        onChange={this.handleChange}
        onSubmit={this.handleSubmit}
      />
    );
  }
}

export default connect()(EditPasswordPage);