import React, { Component } from 'react';
import ForgotPassword from '../../pages/Password/RecoverAccount';
import { passwordInvoke } from '../../actions/forgotPassword';

class ForgotPasswordPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      emailHasError: true,
      emailError: '',
      email: '',
    };
  }

  validateEmail = (email) => {
    if (email.length === 0) {
      this.setState({ emailError: 'Email is required', emailHasError: true });
    } else if (!email.match(/^[A-Za-z0-9.+_-]+@[A-Za-z0-9._-]+\.[a-zA-Z]{2,}$/)) {
      this.setState({ emailError: 'Invalid email format', emailHasError: true });
    } else {
      this.setState({ emailError: '', emailHasError: false });
    }
  }

  handleChange = (evt) => {
    this.setState({ [evt.target.name]: evt.target.value });
    // if (evt.target.id === 'email') {
    //   this.validateEmail(evt.target.value);
    // }
  }

  handleSubmit = (event) => {
    const { email } = this.state;
    event.preventDefault();
    passwordInvoke(email);
  };

  render() {
    const { emailError, emailHasError } = this.state;
    return (
      <ForgotPassword
        handleChange={this.handleChange}
        handleSubmit={this.handleSubmit}
        emailError={emailError}
        emailHasError={emailHasError}
      />
    );
  }
}

export default ForgotPasswordPage;