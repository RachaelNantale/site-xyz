import axios from 'axios';
const API_URL = 'http://localhost:8000';

export default class RequestsUtility {

    // All GET helper methods

    getAllCategories(){
        const url = `${API_URL}/store/api/categories/`;
        return axios.get(url).then(response => response.data);
    }

    getAllProducts() {
        const url = `${API_URL}/store/api/products/`;
        return axios.get(url, {
                    headers: {
                      Authorization: `JWT ${localStorage.getItem('token')}`
                    }
                })
                .then(response => response.data)
                .catch(error => console.log(error));
    }

    getProductById(id){
        const url = `${API_URL}/store/api/products/${id}/`;
        return axios.get(url).then(response => response.data)
    }

    // getCurrentUser(){
    //     const url = `${API_URL}/auth/current_user/`;
    //     return axios.get(url).then(response => response.data);
    // }

    // TODO: create helper methods for Users, order, reviews
}
