import React from 'react';
// import Footer from './Footer';
// import Navbar from './Navbar';
import ImageCarousel from '../pages/Carousel/ImageCarousel'
import Categories from '../pages/Categories/categories';
import Upgrades from '../pages/Upgrades/upgrades';


class Homepage extends React.Component {
  constructor() {
    super();
    this.state = {
      logged_in: localStorage.getItem('token') ? true : false,
      user_info: {}
    }
  }

  render() {
    return (
      <div>
        {/* <Navbar logged_in={this.state.logged_in} user_info={this.state.user_info} /> */}
        <ImageCarousel />
        <br></br>
        <br></br>
        <Categories />
        <br></br>
        <br></br>
        <Upgrades />
        {/* <Footer />  */}
      </div>

    )
  }

}

export default Homepage;