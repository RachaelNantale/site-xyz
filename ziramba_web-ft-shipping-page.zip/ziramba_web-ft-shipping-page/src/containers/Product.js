import React from 'react';
import { withRouter } from 'react-router-dom'

// import Navbar from './Navbar';
import Product from '../pages/Product/singleProduct';
// import Footer from './Footer';


class ProductsList extends React.Component{

    constructor(){
        super();
        this.state = {
            products: []
        }
    }

    // Get products data from the backend
    componentDidMount() {
        // var self = this;
        // requestUtility.getAllProducts().then(function (result) {
        //     self.setState({
        //         products: result,
        //     });
        // });
    }

    render(){
        return (
            <div>
            {/* <Navbar/> */}
            <Product/>
            {/* <Footer/> */}
            </div>
        )
    }

}
export default withRouter(ProductsList);