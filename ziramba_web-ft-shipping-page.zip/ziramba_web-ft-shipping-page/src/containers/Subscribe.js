import React from 'react';

import {
    Container,
    Grid,
    Header,
    Segment,
    Button,
} from 'semantic-ui-react';

const Subscribe = () => (
    <Segment inverted vertical color='grey'>
      <Container textAlign='center'>
        <Grid inverted stackable>
          <Grid.Column width={7}>
            <Header inverted as='h4' content='Your voice matters' />
            <p>
              We 'd love to learn more about your shopping experiences on Ziramba.com and how we can improve!.
            </p>
            <Button> Take Survey</Button>
          </Grid.Column>
        </Grid>
      </Container>
    </Segment>


)

export default Subscribe;