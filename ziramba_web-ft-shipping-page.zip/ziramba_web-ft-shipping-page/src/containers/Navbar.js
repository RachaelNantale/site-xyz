import React from "react";
import { Link, withRouter } from "react-router-dom";
import {
  Menu,
  Image,
  Input,
  Button,
  Container,
  Dropdown,
  Label,
  Icon
} from "semantic-ui-react";
import RequestsUtility from "./RequestsUtility";
import logo from "../assets/main_logo_edited.png";

const requestUtility = new RequestsUtility();

class Navbar extends React.Component {
  constructor() {
    super();
    this.state = {
      categories: []
    };
    this.handleSelection = this.handleSelection.bind(this);
  }

  // Get categories from the backend
  componentDidMount() {
    var self = this;
    requestUtility.getAllCategories().then(function(result) {
      self.setState({
        categories: result
      });
    });
  }

  logout = () => {
    localStorage.clear();
    window.location.replace('/login');
  }


  handleSelection = e => {
    console.log(e.target.value);
    // this.props.history.push(`/categories/${e.target.}`);
  };
  render() {
    const categories = this.state.categories.map(category => (
      <Dropdown.Item key={category.name} value={category.id}>
        {category.name}
      </Dropdown.Item>
    ));
    // const isLoggedIn = () => (localStorage.getItem('token'));
    return (
      <div>
        <Container fluid>
        <Menu secondary>
          <Menu.Menu>
            <Menu.Item>
              <Image
                size="small"
                src={logo}
                style={{ marginRight: "1.5em" }}
                as="a"
                href="/"
              />
            </Menu.Item>
            <Menu.Item>
              <Input size="big" icon="search" placeholder="Search..." />
            </Menu.Item>
          </Menu.Menu>
          <Menu.Menu position="right">
            <Menu.Item as="a">
              <Icon name="cart" />
              <Label floating>0</Label>
            </Menu.Item>
            <Menu.Item position="right">
              <Link to="/login">
                <Button>Log in</Button>
              </Link>
              <Link to="/signup">
                <Button style={{ marginLeft: "0.5em" }}>Sign Up</Button>
              </Link>
            </Menu.Item>
          </Menu.Menu>
        </Menu>

        <Menu inverted size="large" color="teal">
          {/* <Container> */}
            <Dropdown item simple text="Departments">
              <Dropdown.Menu onChange={this.handleSelection}>
                {categories}
                <Dropdown.Divider />
                <Dropdown.Item>All Departments</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
            <Menu.Item position="right">
              <Icon name="list" /> My shopping list
            </Menu.Item>
          {/* </Container> */}
        </Menu>
        </Container>
      </div>
    );
  }
}

export default withRouter(Navbar);
